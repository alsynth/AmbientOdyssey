# Ambient Odyssey — Changelog

## v0.2.10

- Performance wave A: added Noisiumed, AllTheLeaks, Smooth Chunk Save, FastSuite and Clumps while freezing the v0.2.9 content baseline.

## v0.2.9

- Locked in Astrological + BetterEnd: New Dawn for continued End testing; restored T.O. Magic via the original mod plus the approved Ambient Odyssey registry fix.

## v0.2.8

- Added Astrological as the first post-Phantasm End-worldgen replacement test.

## v0.2.7

- Restored Ice & Fire CE and removed End's Phantasm after the v0.2.6 worldgen A/B.

## v0.2.6

- Diagnostic A/B: temporarily removed Ice & Fire CE and corrected the FTB Chunks map-unbind identifier.

## v0.2.5

- Diagnostic A/B: removed Chunk Sending entirely after 3.9 and 4.1 showed no meaningful improvement to chunk/teleport stalls.

## v0.2.4

- Diagnostic patch: updated Chunk Sending to 4.1, made the FTB/voice/accessory keybind defaults reliable, and removed the Accessories inventory-button clutter while keeping Ice & Fire + Phantasm unchanged for controlled worldgen testing.

## v0.2.3

- Updated the Simply Swords/More tooltip stack, added clean pack defaults for narrator/FTB Chunks, and disabled Bosses'Rise's extra dodge roll and oversized boss bars.

## v0.2.2

- Fixed the Simply More tooltip crash, raised NeoForge to 21.1.252, removed JEBr, and added working CurseForge RAM/icon metadata plus an Accessories button offset.

## v0.2.1

- Updated Cataclysm Spellbooks + JEI for registry/search testing; reduced JEI search indexing overhead.

## v0.2.0

- First major content wave: restored donor exploration/RPG/QoL content, Ars Nouveau integration, and a patched 1.21.1 T.O. Magic build.

## v0.1.12

- Replaced Sodium with Embeddium 1.0.15 to resolve the Supplementaries/Sodium startup conflict.

## v0.1.11

- Downgraded Sodium 0.8.13 → 0.6.13 to fix the early OpenGL startup stall.

## v0.1.10

- Added Sodium, ImmediatelyFast, and Lithium as the baseline performance stack.

## v0.1.9

- Parked JET, Dungeon Now Loading, Crazy Chambers, and Desire Paths/GSTools after log-confirmed initialization/worldgen errors.

## v0.1.8

- Chunk-performance diagnostic pass: added Structure Essentials, Chunk Sending, and ServerCore; capped Just Enough Threads at 4 workers.

## v0.1.7

- Fixed Ice & Fire CE's vanilla-menu toggle and added Just Enough Threads for JEI startup/world-entry performance.

## v0.1.6

- Performance/isolation pass: parked Cobblemon + Shine, added ModernFix/FerriteCore, and pinned Desire Paths/GSTools to matching v1.40 builds.

## v0.1.5

- Restored vanilla UI/loading visuals; added JEI and exploration/QoL JEI addons.

## v0.1.4

- Parked Celestial Artifacts/Core due to their broken 1.21.1 L2Tabs compatibility; removed the temporary Accessories pin.

## v0.1.3

- Tried an Accessories beta.49 pin for the L2Tabs crash; it did not resolve it.

## v0.1.2

- Removed T.O Magic 'n Extras: its deprecated 1.21.1 build crashes during mod registration.

## v0.1.1

- Updated NeoForge to 21.1.248.
- Added the missing Cupboard dependency.
