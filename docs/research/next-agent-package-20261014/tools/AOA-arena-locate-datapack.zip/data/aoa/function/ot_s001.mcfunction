function aoa:ot_l001
schedule function aoa:ot_s002 20t
