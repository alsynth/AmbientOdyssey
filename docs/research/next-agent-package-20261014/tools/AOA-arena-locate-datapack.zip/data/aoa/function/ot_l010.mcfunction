scoreboard players set #f aoa_s 0
scoreboard players set #d aoa_s 0
execute in minecraft:the_nether positioned 1500 64 1500 store success score #f aoa_s store result score #d aoa_s run locate structure block_factorys_bosses:underworld_arena
tellraw @a ["AOA|LOCATE|block_factorys_bosses:underworld_arena|the_nether|origin=1500,1500|found=", {"score": {"name": "#f", "objective": "aoa_s"}}, "|dist=", {"score": {"name": "#d", "objective": "aoa_s"}}]
