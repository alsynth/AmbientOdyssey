function aoa:ow_l010
schedule function aoa:ow_s011 20t
