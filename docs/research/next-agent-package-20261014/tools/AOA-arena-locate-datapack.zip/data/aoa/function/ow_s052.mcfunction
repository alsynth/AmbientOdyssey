function aoa:ow_l052
schedule function aoa:ow_s053 20t
