function aoa:ow_l001
schedule function aoa:ow_s002 20t
