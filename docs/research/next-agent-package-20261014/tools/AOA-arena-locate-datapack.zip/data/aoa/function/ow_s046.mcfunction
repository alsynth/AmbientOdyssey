function aoa:ow_l046
schedule function aoa:ow_s047 20t
