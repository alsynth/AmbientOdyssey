function aoa:ow_l066
schedule function aoa:ow_s067 20t
