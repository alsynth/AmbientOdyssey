function aoa:ow_l025
schedule function aoa:ow_s026 20t
