function aoa:ow_l030
schedule function aoa:ow_s031 20t
