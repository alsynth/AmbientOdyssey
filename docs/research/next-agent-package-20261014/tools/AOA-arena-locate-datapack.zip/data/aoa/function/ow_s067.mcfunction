function aoa:ow_l067
schedule function aoa:ow_s068 20t
