function aoa:ot_l023
schedule function aoa:ot_s024 20t
