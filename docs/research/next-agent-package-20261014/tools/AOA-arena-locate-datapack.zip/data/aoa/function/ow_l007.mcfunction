scoreboard players set #f aoa_s 0
scoreboard players set #d aoa_s 0
execute in minecraft:overworld positioned 0 64 0 store success score #f aoa_s store result score #d aoa_s run locate structure block_factorys_bosses:dragon_tower
tellraw @a ["AOA|LOCATE|block_factorys_bosses:dragon_tower|overworld|origin=0,0|found=", {"score": {"name": "#f", "objective": "aoa_s"}}, "|dist=", {"score": {"name": "#d", "objective": "aoa_s"}}]
