function aoa:ot_l002
schedule function aoa:ot_s003 20t
