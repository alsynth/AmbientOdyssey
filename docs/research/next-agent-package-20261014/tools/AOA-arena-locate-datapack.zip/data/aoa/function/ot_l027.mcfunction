scoreboard players set #f aoa_s 0
scoreboard players set #d aoa_s 0
execute in eternal_starlight:starlight positioned 3000 64 3000 store success score #f aoa_s store result score #d aoa_s run locate structure eternal_starlight:cursed_garden
tellraw @a ["AOA|LOCATE|eternal_starlight:cursed_garden|eternal_starlight|origin=3000,3000|found=", {"score": {"name": "#f", "objective": "aoa_s"}}, "|dist=", {"score": {"name": "#d", "objective": "aoa_s"}}]
