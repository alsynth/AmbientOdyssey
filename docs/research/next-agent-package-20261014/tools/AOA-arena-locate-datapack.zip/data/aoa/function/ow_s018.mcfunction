function aoa:ow_l018
schedule function aoa:ow_s019 20t
