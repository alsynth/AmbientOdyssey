function aoa:ow_l047
schedule function aoa:ow_s048 20t
