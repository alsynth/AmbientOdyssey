function aoa:ow_l023
schedule function aoa:ow_s024 20t
