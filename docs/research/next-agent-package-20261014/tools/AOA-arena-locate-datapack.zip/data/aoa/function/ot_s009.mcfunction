function aoa:ot_l009
schedule function aoa:ot_s010 20t
