function aoa:ow_l009
schedule function aoa:ow_s010 20t
