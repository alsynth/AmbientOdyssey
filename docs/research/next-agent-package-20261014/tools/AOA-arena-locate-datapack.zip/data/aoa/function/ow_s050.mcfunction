function aoa:ow_l050
schedule function aoa:ow_s051 20t
