function aoa:ot_l025
schedule function aoa:ot_s026 20t
