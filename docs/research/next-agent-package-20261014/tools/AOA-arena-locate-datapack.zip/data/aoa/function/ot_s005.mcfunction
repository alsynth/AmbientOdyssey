function aoa:ot_l005
schedule function aoa:ot_s006 20t
