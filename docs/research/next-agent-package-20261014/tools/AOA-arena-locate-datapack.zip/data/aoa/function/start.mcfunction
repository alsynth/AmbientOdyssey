function aoa:init
tellraw @a "AOA|PLAN|87"
schedule function aoa:ow_s001 40t
