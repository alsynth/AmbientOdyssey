function aoa:ot_l017
schedule function aoa:ot_s018 20t
