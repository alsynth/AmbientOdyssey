scoreboard players set #f aoa_s 0
scoreboard players set #d aoa_s 0
execute in minecraft:overworld positioned -5000 64 3000 store success score #f aoa_s store result score #d aoa_s run locate structure block_factorys_bosses:yeti_hideout
tellraw @a ["AOA|LOCATE|block_factorys_bosses:yeti_hideout|overworld|origin=-5000,3000|found=", {"score": {"name": "#f", "objective": "aoa_s"}}, "|dist=", {"score": {"name": "#d", "objective": "aoa_s"}}]
