function aoa:ow_l076
schedule function aoa:ow_s077 20t
