function aoa:ot_l010
schedule function aoa:ot_s011 20t
