function aoa:init
tellraw @a "AOA|PLAN|28"
schedule function aoa:ot_s001 40t
