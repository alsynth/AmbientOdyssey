function aoa:ow_l038
schedule function aoa:ow_s039 20t
