function aoa:ow_l022
schedule function aoa:ow_s023 20t
