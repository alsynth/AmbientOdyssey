function aoa:ow_l002
schedule function aoa:ow_s003 20t
