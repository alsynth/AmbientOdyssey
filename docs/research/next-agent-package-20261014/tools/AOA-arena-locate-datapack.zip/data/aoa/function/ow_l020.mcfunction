scoreboard players set #f aoa_s 0
scoreboard players set #d aoa_s 0
execute in minecraft:overworld positioned 0 64 0 store success score #f aoa_s store result score #d aoa_s run locate structure eternal_starlight:portal_ruins_forest
tellraw @a ["AOA|LOCATE|eternal_starlight:portal_ruins_forest|overworld|origin=0,0|found=", {"score": {"name": "#f", "objective": "aoa_s"}}, "|dist=", {"score": {"name": "#d", "objective": "aoa_s"}}]
