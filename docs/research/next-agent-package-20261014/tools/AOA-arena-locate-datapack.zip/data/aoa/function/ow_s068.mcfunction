function aoa:ow_l068
schedule function aoa:ow_s069 20t
