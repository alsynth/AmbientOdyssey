function aoa:ow_l027
schedule function aoa:ow_s028 20t
