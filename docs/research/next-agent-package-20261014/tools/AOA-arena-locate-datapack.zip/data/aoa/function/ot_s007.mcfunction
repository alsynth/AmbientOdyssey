function aoa:ot_l007
schedule function aoa:ot_s008 20t
