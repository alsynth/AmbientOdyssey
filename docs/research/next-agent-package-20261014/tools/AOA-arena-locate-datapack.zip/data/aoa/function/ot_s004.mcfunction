function aoa:ot_l004
schedule function aoa:ot_s005 20t
