function aoa:ow_l056
schedule function aoa:ow_s057 20t
