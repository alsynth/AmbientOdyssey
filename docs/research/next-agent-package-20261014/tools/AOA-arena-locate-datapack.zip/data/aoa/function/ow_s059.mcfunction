function aoa:ow_l059
schedule function aoa:ow_s060 20t
