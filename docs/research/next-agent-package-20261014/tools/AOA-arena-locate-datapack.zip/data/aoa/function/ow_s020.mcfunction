function aoa:ow_l020
schedule function aoa:ow_s021 20t
