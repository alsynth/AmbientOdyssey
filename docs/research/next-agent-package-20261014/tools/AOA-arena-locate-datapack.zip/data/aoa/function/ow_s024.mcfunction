function aoa:ow_l024
schedule function aoa:ow_s025 20t
