function aoa:ot_l020
schedule function aoa:ot_s021 20t
