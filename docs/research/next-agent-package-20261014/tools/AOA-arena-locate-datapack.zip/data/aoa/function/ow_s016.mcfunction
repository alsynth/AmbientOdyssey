function aoa:ow_l016
schedule function aoa:ow_s017 20t
