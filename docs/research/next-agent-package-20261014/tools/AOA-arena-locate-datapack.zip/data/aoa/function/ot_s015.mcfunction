function aoa:ot_l015
schedule function aoa:ot_s016 20t
