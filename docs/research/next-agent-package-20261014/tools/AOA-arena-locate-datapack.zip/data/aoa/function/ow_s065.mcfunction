function aoa:ow_l065
schedule function aoa:ow_s066 20t
