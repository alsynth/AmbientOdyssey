scoreboard players set #f aoa_s 0
scoreboard players set #d aoa_s 0
execute in minecraft:overworld positioned 0 64 0 store success score #f aoa_s store result score #d aoa_s run locate structure aquamirae:shipwreck
tellraw @a ["AOA|LOCATE|aquamirae:shipwreck|overworld|origin=0,0|found=", {"score": {"name": "#f", "objective": "aoa_s"}}, "|dist=", {"score": {"name": "#d", "objective": "aoa_s"}}]
