function aoa:ow_l063
schedule function aoa:ow_s064 20t
