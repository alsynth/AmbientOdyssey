function aoa:ot_l021
schedule function aoa:ot_s022 20t
