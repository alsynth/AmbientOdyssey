function aoa:ow_l031
schedule function aoa:ow_s032 20t
