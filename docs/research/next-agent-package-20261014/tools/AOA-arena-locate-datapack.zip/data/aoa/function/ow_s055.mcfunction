function aoa:ow_l055
schedule function aoa:ow_s056 20t
