scoreboard players set #f aoa_s 0
scoreboard players set #d aoa_s 0
execute in minecraft:the_end positioned 2500 64 2500 store success score #f aoa_s store result score #d aoa_s run locate structure archaion:ancient_keep
tellraw @a ["AOA|LOCATE|archaion:ancient_keep|the_end|origin=2500,2500|found=", {"score": {"name": "#f", "objective": "aoa_s"}}, "|dist=", {"score": {"name": "#d", "objective": "aoa_s"}}]
