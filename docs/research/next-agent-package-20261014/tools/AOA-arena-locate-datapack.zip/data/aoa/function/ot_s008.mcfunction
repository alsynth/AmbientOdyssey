function aoa:ot_l008
schedule function aoa:ot_s009 20t
