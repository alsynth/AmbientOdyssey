function aoa:ow_l026
schedule function aoa:ow_s027 20t
