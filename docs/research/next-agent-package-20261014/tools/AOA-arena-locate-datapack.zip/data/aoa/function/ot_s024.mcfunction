function aoa:ot_l024
schedule function aoa:ot_s025 20t
