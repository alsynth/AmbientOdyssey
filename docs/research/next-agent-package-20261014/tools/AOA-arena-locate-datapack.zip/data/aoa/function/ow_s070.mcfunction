function aoa:ow_l070
schedule function aoa:ow_s071 20t
