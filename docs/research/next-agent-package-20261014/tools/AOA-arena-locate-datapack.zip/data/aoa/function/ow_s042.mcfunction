function aoa:ow_l042
schedule function aoa:ow_s043 20t
