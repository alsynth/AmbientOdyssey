function aoa:ow_l082
schedule function aoa:ow_s083 20t
