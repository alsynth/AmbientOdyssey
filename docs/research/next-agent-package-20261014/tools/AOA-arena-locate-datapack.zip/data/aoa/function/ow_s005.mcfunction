function aoa:ow_l005
schedule function aoa:ow_s006 20t
