function aoa:ow_l071
schedule function aoa:ow_s072 20t
