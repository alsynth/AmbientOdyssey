scoreboard players set #f aoa_s 0
scoreboard players set #d aoa_s 0
execute in minecraft:overworld positioned 5000 64 5000 store success score #f aoa_s store result score #d aoa_s run locate structure cataclysm:cursed_pyramid
tellraw @a ["AOA|LOCATE|cataclysm:cursed_pyramid|overworld|origin=5000,5000|found=", {"score": {"name": "#f", "objective": "aoa_s"}}, "|dist=", {"score": {"name": "#d", "objective": "aoa_s"}}]
