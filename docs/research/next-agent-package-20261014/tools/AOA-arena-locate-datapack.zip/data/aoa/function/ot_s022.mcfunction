function aoa:ot_l022
schedule function aoa:ot_s023 20t
