function aoa:ow_l040
schedule function aoa:ow_s041 20t
