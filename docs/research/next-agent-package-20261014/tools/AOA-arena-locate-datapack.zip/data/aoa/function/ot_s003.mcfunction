function aoa:ot_l003
schedule function aoa:ot_s004 20t
