function aoa:ow_l051
schedule function aoa:ow_s052 20t
