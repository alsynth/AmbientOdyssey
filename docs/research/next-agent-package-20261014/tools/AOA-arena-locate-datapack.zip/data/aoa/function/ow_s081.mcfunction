function aoa:ow_l081
schedule function aoa:ow_s082 20t
