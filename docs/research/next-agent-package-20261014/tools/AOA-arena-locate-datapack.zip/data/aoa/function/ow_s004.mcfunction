function aoa:ow_l004
schedule function aoa:ow_s005 20t
