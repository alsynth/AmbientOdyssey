function aoa:ot_l018
schedule function aoa:ot_s019 20t
