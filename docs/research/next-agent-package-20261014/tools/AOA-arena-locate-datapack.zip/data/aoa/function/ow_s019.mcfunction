function aoa:ow_l019
schedule function aoa:ow_s020 20t
