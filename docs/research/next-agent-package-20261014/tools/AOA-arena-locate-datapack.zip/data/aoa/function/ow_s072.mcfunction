function aoa:ow_l072
schedule function aoa:ow_s073 20t
