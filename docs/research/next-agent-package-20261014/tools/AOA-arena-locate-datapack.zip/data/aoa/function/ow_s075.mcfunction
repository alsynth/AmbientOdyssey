function aoa:ow_l075
schedule function aoa:ow_s076 20t
