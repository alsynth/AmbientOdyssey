function aoa:ot_l006
schedule function aoa:ot_s007 20t
