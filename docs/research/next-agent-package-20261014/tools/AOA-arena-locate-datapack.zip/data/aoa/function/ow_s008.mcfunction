function aoa:ow_l008
schedule function aoa:ow_s009 20t
