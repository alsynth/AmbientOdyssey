function aoa:ow_l041
schedule function aoa:ow_s042 20t
