scoreboard objectives add aoa_s dummy
tellraw @a "AOA|VERSION|2"
