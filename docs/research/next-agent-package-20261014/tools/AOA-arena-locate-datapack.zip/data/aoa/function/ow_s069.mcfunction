function aoa:ow_l069
schedule function aoa:ow_s070 20t
