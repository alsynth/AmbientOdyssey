function aoa:ot_l028
tellraw @a "AOA|DONE"
