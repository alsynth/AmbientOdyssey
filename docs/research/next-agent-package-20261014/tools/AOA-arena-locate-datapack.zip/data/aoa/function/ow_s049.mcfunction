function aoa:ow_l049
schedule function aoa:ow_s050 20t
