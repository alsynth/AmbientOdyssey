function aoa:ow_l064
schedule function aoa:ow_s065 20t
