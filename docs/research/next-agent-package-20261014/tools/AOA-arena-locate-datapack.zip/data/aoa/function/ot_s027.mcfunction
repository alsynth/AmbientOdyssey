function aoa:ot_l027
schedule function aoa:ot_s028 20t
