function aoa:ow_l087
tellraw @a "AOA|DONE"
