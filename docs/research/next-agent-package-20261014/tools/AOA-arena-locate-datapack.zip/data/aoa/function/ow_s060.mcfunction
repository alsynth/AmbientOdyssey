function aoa:ow_l060
schedule function aoa:ow_s061 20t
