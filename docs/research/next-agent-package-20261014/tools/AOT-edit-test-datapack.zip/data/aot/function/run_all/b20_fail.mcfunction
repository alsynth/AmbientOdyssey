tellraw @a ["AOT|BOSS|20|ars_nouveau:wilden_boss|NO_ENTITY"]
schedule function aot:run_all/b20_next 20t
