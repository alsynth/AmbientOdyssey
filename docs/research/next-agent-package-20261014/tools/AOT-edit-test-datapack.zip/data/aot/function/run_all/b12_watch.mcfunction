execute if score #active aot_s matches 1 if score #idx aot_s matches 12 run function aot:run_all/b12_stall
