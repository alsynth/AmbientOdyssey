tellraw @a ["AOT|BOSS|4|alexscaves:hullbreaker|NO_ENTITY"]
schedule function aot:run_alexscaves/b04_next 20t
