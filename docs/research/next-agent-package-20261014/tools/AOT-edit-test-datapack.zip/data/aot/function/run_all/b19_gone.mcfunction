tellraw @a ["AOT|BOSS|19|graveyard:nightmare|GONE_AFTER_A"]
schedule function aot:run_all/b19_next 20t
