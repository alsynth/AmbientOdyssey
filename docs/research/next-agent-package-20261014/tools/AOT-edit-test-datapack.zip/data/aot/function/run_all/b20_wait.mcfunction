function aot:run_all/b21_start
