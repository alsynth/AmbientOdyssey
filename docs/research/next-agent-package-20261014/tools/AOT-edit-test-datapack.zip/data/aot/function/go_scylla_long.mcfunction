execute if score #st_ok aot_s matches 1 run tellraw @a "AOT|CHAIN|scylla_long|phase_ticks=1200"
execute if score #st_ok aot_s matches 1 run function aot:run_scylla_long/b00_start
execute unless score #st_ok aot_s matches 1 run function aot:selftest_fail
