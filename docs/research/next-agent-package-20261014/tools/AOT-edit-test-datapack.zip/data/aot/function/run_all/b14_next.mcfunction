kill @e[type=!minecraft:player]
schedule function aot:run_all/b14_wait 40t
