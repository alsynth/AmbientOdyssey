scoreboard players set #run aot_s 0
scoreboard players set #idx aot_s 10
kill @e[type=!minecraft:player]
tellraw @a ["AOT|BOSS|10|deep_aether:eots_controller|START"]
schedule function aot:run_all/b10_base 20t
schedule function aot:run_all/b10_watch 1700t
data modify storage aot:cur id set value "deep_aether:eots_controller"
data modify storage aot:cur init set value "aot:init_boss"
function aot:summon with storage aot:cur
