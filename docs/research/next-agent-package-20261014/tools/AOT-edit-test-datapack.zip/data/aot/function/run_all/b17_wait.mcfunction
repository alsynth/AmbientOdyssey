function aot:run_all/b18_start
