scoreboard players set #run aot_s 0
tellraw @a ["AOT|BOSS|3|twilightforest:minoshroom|STALL_SKIPPED"]
schedule clear aot:run_all/b03_base
schedule clear aot:run_all/b03_mid
schedule clear aot:run_all/b03_post
schedule clear aot:run_all/b03_end
function aot:run_all/b03_next
