attribute @e[tag=aot_boss,limit=1,sort=nearest] minecraft:generic.max_health modifier add aot:hp 3.0 add_multiplied_base
attribute @e[tag=aot_boss,limit=1,sort=nearest] minecraft:generic.attack_damage modifier add aot:dmg 3.0 add_multiplied_base
data modify entity @e[tag=aot_boss,limit=1,sort=nearest] Health set value 100000f
schedule function aot:run_alexscaves/b05_post 4t
