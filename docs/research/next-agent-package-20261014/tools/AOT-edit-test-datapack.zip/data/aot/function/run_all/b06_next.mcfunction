kill @e[type=!minecraft:player]
schedule function aot:run_all/b06_wait 40t
