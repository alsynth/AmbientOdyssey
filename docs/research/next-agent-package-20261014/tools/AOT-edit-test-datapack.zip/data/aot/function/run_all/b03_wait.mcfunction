function aot:run_all/b04_start
