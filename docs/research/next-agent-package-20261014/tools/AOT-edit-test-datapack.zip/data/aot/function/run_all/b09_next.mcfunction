kill @e[type=!minecraft:player]
schedule function aot:run_all/b09_wait 40t
