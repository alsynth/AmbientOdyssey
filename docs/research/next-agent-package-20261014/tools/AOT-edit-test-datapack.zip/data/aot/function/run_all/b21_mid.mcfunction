scoreboard players set #run aot_s 0
tellraw @a ["AOT|END|",{"score":{"name":"#idx","objective":"aot_s"}},"|A|cnt=",{"score":{"name":"#cnt","objective":"aot_s"}},"|sum10=",{"score":{"name":"#sum","objective":"aot_s"}}]
execute unless entity @e[tag=aot_boss] run function aot:run_all/b21_gone
execute if entity @e[tag=aot_boss] run function aot:run_all/b21_mod
