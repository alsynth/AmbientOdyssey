tellraw @a ["AOT|BOSS|5|twilightforest:knight_phantom|NO_ENTITY"]
schedule function aot:run_all/b05_next 20t
