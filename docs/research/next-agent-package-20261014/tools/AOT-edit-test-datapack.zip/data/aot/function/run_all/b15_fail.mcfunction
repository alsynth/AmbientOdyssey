tellraw @a ["AOT|BOSS|15|alexscaves:hullbreaker|NO_ENTITY"]
schedule function aot:run_all/b15_next 20t
