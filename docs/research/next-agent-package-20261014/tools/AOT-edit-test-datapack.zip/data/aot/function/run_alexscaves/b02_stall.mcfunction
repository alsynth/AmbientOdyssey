scoreboard players set #run aot_s 0
tellraw @a ["AOT|BOSS|2|alexscaves:tremorzilla|STALL_SKIPPED"]
schedule clear aot:run_alexscaves/b02_base
schedule clear aot:run_alexscaves/b02_mid
schedule clear aot:run_alexscaves/b02_post
schedule clear aot:run_alexscaves/b02_end
function aot:run_alexscaves/b02_next
