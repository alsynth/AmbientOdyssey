tellraw @a ["AOT|BOSS|2|twilightforest:lich|NO_ENTITY"]
schedule function aot:run_all/b02_next 20t
