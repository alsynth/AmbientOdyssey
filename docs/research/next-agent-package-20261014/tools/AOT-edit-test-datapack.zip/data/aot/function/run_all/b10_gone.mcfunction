tellraw @a ["AOT|BOSS|10|deep_aether:eots_controller|GONE_AFTER_A"]
schedule function aot:run_all/b10_next 20t
