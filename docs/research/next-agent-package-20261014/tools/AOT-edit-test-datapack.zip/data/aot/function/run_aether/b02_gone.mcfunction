tellraw @a ["AOT|BOSS|2|deep_aether:eots_controller|GONE_AFTER_A"]
schedule function aot:run_aether/b02_next 20t
