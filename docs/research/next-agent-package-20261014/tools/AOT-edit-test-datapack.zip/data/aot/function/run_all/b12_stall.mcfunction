scoreboard players set #run aot_s 0
tellraw @a ["AOT|BOSS|12|alexscaves:luxtructosaurus|STALL_SKIPPED"]
schedule clear aot:run_all/b12_base
schedule clear aot:run_all/b12_mid
schedule clear aot:run_all/b12_post
schedule clear aot:run_all/b12_end
function aot:run_all/b12_next
