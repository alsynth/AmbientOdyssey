execute unless entity @e[tag=aot_boss] run function aot:run_alexscaves/b05_fail
execute if entity @e[tag=aot_boss] run function aot:run_alexscaves/b05_base2
