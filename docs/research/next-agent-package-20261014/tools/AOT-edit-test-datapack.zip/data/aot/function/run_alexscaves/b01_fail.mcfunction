tellraw @a ["AOT|BOSS|1|alexscaves:luxtructosaurus|NO_ENTITY"]
schedule function aot:run_alexscaves/b01_next 20t
