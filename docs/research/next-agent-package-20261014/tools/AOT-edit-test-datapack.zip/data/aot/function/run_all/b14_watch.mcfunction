execute if score #active aot_s matches 1 if score #idx aot_s matches 14 run function aot:run_all/b14_stall
