tellraw @a ["AOT|BOSS|5|alexscaves:forsaken|GONE_AFTER_A"]
schedule function aot:run_alexscaves/b05_next 20t
