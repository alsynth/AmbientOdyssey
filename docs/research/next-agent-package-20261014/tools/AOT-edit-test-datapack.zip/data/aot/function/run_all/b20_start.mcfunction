scoreboard players set #run aot_s 0
scoreboard players set #idx aot_s 20
kill @e[type=!minecraft:player]
tellraw @a ["AOT|BOSS|20|ars_nouveau:wilden_boss|START"]
schedule function aot:run_all/b20_base 20t
schedule function aot:run_all/b20_watch 1700t
data modify storage aot:cur id set value "ars_nouveau:wilden_boss"
data modify storage aot:cur init set value "aot:init_boss"
function aot:summon with storage aot:cur
