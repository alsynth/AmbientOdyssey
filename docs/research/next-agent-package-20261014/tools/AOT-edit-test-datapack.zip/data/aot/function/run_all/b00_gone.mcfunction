tellraw @a ["AOT|BOSS|0|minecraft:husk|GONE_AFTER_A"]
schedule function aot:run_all/b00_next 20t
