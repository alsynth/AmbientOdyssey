tellraw @a ["AOT|BOSS|3|twilightforest:minoshroom|GONE_AFTER_A"]
schedule function aot:run_all/b03_next 20t
