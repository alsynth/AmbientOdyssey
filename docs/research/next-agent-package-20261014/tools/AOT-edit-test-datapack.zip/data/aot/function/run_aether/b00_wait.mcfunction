function aot:run_aether/b01_start
