scoreboard players set #run aot_s 0
tellraw @a ["AOT|BOSS|0|minecraft:husk|STALL_SKIPPED"]
schedule clear aot:run_all/b00_base
schedule clear aot:run_all/b00_mid
schedule clear aot:run_all/b00_post
schedule clear aot:run_all/b00_end
function aot:run_all/b00_next
