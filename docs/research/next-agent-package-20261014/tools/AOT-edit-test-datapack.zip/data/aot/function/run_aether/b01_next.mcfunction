kill @e[type=!minecraft:player]
schedule function aot:run_aether/b01_wait 40t
