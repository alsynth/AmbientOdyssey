kill @e[type=!minecraft:player]
schedule function aot:run_alexscaves/b03_wait 40t
