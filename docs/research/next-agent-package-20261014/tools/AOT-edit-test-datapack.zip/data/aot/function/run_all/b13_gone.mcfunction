tellraw @a ["AOT|BOSS|13|alexscaves:tremorzilla|GONE_AFTER_A"]
schedule function aot:run_all/b13_next 20t
