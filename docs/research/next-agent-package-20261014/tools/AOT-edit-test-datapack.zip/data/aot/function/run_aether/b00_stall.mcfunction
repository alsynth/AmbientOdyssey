scoreboard players set #run aot_s 0
tellraw @a ["AOT|BOSS|0|minecraft:husk|STALL_SKIPPED"]
schedule clear aot:run_aether/b00_base
schedule clear aot:run_aether/b00_mid
schedule clear aot:run_aether/b00_post
schedule clear aot:run_aether/b00_end
function aot:run_aether/b00_next
