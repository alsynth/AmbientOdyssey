scoreboard players set #run aot_s 0
tellraw @a ["AOT|BOSS|8|twilightforest:alpha_yeti|STALL_SKIPPED"]
schedule clear aot:run_all/b08_base
schedule clear aot:run_all/b08_mid
schedule clear aot:run_all/b08_post
schedule clear aot:run_all/b08_end
function aot:run_all/b08_next
