execute unless entity @e[tag=aot_boss] run function aot:run_all/b17_fail
execute if entity @e[tag=aot_boss] run function aot:run_all/b17_base2
