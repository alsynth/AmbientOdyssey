scoreboard players set #run aot_s 0
tellraw @a ["AOT|END|",{"score":{"name":"#idx","objective":"aot_s"}},"|B|cnt=",{"score":{"name":"#cnt","objective":"aot_s"}},"|sum10=",{"score":{"name":"#sum","objective":"aot_s"}}]
tellraw @a ["AOT|BOSS|11|undergarden:forgotten_guardian|DONE"]
schedule function aot:run_all/b11_next 20t
