scoreboard players set #run aot_s 0
tellraw @a ["AOT|BOSS|15|alexscaves:hullbreaker|STALL_SKIPPED"]
schedule clear aot:run_all/b15_base
schedule clear aot:run_all/b15_mid
schedule clear aot:run_all/b15_post
schedule clear aot:run_all/b15_end
function aot:run_all/b15_next
