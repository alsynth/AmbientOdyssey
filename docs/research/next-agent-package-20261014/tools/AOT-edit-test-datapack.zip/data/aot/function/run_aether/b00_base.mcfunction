execute unless entity @e[tag=aot_boss] run function aot:run_aether/b00_fail
execute if entity @e[tag=aot_boss] run function aot:run_aether/b00_base2
