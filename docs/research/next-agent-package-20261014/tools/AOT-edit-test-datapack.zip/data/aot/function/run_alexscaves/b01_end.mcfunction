scoreboard players set #run aot_s 0
tellraw @a ["AOT|END|",{"score":{"name":"#idx","objective":"aot_s"}},"|B|cnt=",{"score":{"name":"#cnt","objective":"aot_s"}},"|sum10=",{"score":{"name":"#sum","objective":"aot_s"}}]
tellraw @a ["AOT|BOSS|1|alexscaves:luxtructosaurus|DONE"]
schedule function aot:run_alexscaves/b01_next 20t
