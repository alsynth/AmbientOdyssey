execute unless entity @e[tag=aot_boss] run function aot:run_all/b08_fail
execute if entity @e[tag=aot_boss] run function aot:run_all/b08_base2
