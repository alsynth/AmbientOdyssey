tellraw @a ["AOT|BOSS|17|aquamirae:captain_cornelia|GONE_AFTER_A"]
schedule function aot:run_all/b17_next 20t
