kill @e[type=!minecraft:player]
schedule function aot:run_all/b19_wait 40t
