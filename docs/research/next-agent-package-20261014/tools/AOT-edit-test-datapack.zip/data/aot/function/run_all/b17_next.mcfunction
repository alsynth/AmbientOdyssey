kill @e[type=!minecraft:player]
schedule function aot:run_all/b17_wait 40t
