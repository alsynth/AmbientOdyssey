kill @e[type=!minecraft:player]
schedule function aot:run_alexscaves/b04_wait 40t
