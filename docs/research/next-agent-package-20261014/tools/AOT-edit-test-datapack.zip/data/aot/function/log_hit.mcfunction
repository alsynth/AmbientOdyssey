scoreboard players add #cnt aot_s 1
scoreboard players operation #sum aot_s += #delta aot_s
tellraw @a ["AOT|HIT|",{"score":{"name":"#idx","objective":"aot_s"}},"|",{"score":{"name":"#phase","objective":"aot_s"}},"|",{"score":{"name":"#delta","objective":"aot_s"}}]
