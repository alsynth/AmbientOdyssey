function aot:run_all/b12_start
