tellraw @a ["AOT|BOSS|9|aether:slider|GONE_AFTER_A"]
schedule function aot:run_all/b09_next 20t
