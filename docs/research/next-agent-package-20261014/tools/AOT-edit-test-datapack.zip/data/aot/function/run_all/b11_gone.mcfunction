tellraw @a ["AOT|BOSS|11|undergarden:forgotten_guardian|GONE_AFTER_A"]
schedule function aot:run_all/b11_next 20t
