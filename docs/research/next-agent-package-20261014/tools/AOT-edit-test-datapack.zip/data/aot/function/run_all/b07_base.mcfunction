execute unless entity @e[tag=aot_boss] run function aot:run_all/b07_fail
execute if entity @e[tag=aot_boss] run function aot:run_all/b07_base2
