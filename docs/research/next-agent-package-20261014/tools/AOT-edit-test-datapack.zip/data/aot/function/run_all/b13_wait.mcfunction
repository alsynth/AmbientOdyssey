function aot:run_all/b14_start
