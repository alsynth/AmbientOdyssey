tellraw @a ["AOT|BOSS|1|aether:slider|GONE_AFTER_A"]
schedule function aot:run_aether/b01_next 20t
