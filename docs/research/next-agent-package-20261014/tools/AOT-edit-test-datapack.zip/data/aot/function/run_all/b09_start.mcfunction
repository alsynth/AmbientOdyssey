scoreboard players set #run aot_s 0
scoreboard players set #idx aot_s 9
kill @e[type=!minecraft:player]
tellraw @a ["AOT|BOSS|9|aether:slider|START"]
schedule function aot:run_all/b09_base 20t
schedule function aot:run_all/b09_watch 1700t
data modify storage aot:cur id set value "aether:slider"
data modify storage aot:cur init set value "aot:init_boss"
function aot:summon with storage aot:cur
