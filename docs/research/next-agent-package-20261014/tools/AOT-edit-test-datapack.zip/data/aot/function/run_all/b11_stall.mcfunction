scoreboard players set #run aot_s 0
tellraw @a ["AOT|BOSS|11|undergarden:forgotten_guardian|STALL_SKIPPED"]
schedule clear aot:run_all/b11_base
schedule clear aot:run_all/b11_mid
schedule clear aot:run_all/b11_post
schedule clear aot:run_all/b11_end
function aot:run_all/b11_next
