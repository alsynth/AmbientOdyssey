tellraw @a ["AOT|BOSS|18|graveyard:lich|NO_ENTITY"]
schedule function aot:run_all/b18_next 20t
