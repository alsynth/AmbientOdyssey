scoreboard players set #run aot_s 0
tellraw @a ["AOT|BOSS|1|alexscaves:luxtructosaurus|STALL_SKIPPED"]
schedule clear aot:run_alexscaves/b01_base
schedule clear aot:run_alexscaves/b01_mid
schedule clear aot:run_alexscaves/b01_post
schedule clear aot:run_alexscaves/b01_end
function aot:run_alexscaves/b01_next
