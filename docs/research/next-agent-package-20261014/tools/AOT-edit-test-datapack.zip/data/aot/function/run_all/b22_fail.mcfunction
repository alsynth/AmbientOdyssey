tellraw @a ["AOT|BOSS|22|cataclysm:ignis|NO_ENTITY"]
schedule function aot:run_all/b22_next 20t
