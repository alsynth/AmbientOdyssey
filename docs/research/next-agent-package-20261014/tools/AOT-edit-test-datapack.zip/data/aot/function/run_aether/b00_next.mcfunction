kill @e[type=!minecraft:player]
schedule function aot:run_aether/b00_wait 40t
