tellraw @a ["AOT|BOSS|14|alexscaves:atlatitan|NO_ENTITY"]
schedule function aot:run_all/b14_next 20t
