execute if score #active aot_s matches 1 if score #idx aot_s matches 6 run function aot:run_all/b06_stall
