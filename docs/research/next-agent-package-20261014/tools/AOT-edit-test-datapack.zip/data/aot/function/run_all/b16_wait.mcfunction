function aot:run_all/b17_start
