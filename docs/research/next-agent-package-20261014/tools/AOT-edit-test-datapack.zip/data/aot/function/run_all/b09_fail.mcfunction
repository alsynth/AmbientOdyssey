tellraw @a ["AOT|BOSS|9|aether:slider|NO_ENTITY"]
schedule function aot:run_all/b09_next 20t
