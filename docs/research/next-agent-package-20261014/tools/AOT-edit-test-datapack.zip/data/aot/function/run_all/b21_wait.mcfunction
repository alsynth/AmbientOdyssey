function aot:run_all/b22_start
