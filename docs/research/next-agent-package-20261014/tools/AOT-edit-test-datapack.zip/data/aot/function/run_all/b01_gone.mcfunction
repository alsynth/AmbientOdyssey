tellraw @a ["AOT|BOSS|1|twilightforest:naga|GONE_AFTER_A"]
schedule function aot:run_all/b01_next 20t
