execute unless entity @e[tag=aot_boss] run function aot:run_all/b19_fail
execute if entity @e[tag=aot_boss] run function aot:run_all/b19_base2
