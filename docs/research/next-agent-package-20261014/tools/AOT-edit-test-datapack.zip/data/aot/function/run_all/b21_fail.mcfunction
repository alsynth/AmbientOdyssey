tellraw @a ["AOT|BOSS|21|netherman:azazel|NO_ENTITY"]
schedule function aot:run_all/b21_next 20t
