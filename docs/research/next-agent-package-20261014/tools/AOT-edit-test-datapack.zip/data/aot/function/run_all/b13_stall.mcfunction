scoreboard players set #run aot_s 0
tellraw @a ["AOT|BOSS|13|alexscaves:tremorzilla|STALL_SKIPPED"]
schedule clear aot:run_all/b13_base
schedule clear aot:run_all/b13_mid
schedule clear aot:run_all/b13_post
schedule clear aot:run_all/b13_end
function aot:run_all/b13_next
