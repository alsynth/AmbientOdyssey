scoreboard players set #run aot_s 0
tellraw @a ["AOT|BOSS|10|deep_aether:eots_controller|STALL_SKIPPED"]
schedule clear aot:run_all/b10_base
schedule clear aot:run_all/b10_mid
schedule clear aot:run_all/b10_post
schedule clear aot:run_all/b10_end
function aot:run_all/b10_next
