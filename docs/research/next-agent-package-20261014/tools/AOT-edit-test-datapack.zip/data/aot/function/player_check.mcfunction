execute store result score #pmax aot_s run attribute @p minecraft:generic.max_health get 1
execute store result score #php aot_s run data get entity @p Health 1
tellraw @a ["AOT|PLAYER|max=",{"score":{"name":"#pmax","objective":"aot_s"}},"|hp=",{"score":{"name":"#php","objective":"aot_s"}}]
