tellraw @a ["AOT|BOSS|17|aquamirae:captain_cornelia|NO_ENTITY"]
schedule function aot:run_all/b17_next 20t
