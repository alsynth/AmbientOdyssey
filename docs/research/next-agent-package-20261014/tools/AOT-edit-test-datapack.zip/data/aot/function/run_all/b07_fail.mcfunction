tellraw @a ["AOT|BOSS|7|twilightforest:snow_queen|NO_ENTITY"]
schedule function aot:run_all/b07_next 20t
