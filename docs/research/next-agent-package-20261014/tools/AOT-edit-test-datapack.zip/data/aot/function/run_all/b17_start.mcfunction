scoreboard players set #run aot_s 0
scoreboard players set #idx aot_s 17
kill @e[type=!minecraft:player]
tellraw @a ["AOT|BOSS|17|aquamirae:captain_cornelia|START"]
schedule function aot:run_all/b17_base 20t
schedule function aot:run_all/b17_watch 1700t
data modify storage aot:cur id set value "aquamirae:captain_cornelia"
data modify storage aot:cur init set value "aot:init_boss"
function aot:summon with storage aot:cur
