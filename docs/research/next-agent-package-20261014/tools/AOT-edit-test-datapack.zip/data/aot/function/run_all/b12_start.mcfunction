scoreboard players set #run aot_s 0
scoreboard players set #idx aot_s 12
kill @e[type=!minecraft:player]
tellraw @a ["AOT|BOSS|12|alexscaves:luxtructosaurus|START"]
schedule function aot:run_all/b12_base 20t
schedule function aot:run_all/b12_watch 1700t
data modify storage aot:cur id set value "alexscaves:luxtructosaurus"
data modify storage aot:cur init set value "aot:init_boss"
function aot:summon with storage aot:cur
