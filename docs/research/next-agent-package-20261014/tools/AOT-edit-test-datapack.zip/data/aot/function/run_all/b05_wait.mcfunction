function aot:run_all/b06_start
