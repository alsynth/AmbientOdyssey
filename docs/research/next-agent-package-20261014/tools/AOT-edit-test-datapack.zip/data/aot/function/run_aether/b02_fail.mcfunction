tellraw @a ["AOT|BOSS|2|deep_aether:eots_controller|NO_ENTITY"]
schedule function aot:run_aether/b02_next 20t
