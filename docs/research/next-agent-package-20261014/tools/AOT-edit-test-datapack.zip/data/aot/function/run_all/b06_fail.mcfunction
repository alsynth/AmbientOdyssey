tellraw @a ["AOT|BOSS|6|twilightforest:ur_ghast|NO_ENTITY"]
schedule function aot:run_all/b06_next 20t
