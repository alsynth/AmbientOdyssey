tellraw @a ["AOT|BOSS|2|alexscaves:tremorzilla|GONE_AFTER_A"]
schedule function aot:run_alexscaves/b02_next 20t
