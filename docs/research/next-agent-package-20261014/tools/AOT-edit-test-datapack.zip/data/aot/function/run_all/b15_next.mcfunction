kill @e[type=!minecraft:player]
schedule function aot:run_all/b15_wait 40t
