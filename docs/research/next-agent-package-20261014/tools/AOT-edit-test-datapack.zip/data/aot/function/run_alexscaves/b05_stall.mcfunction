scoreboard players set #run aot_s 0
tellraw @a ["AOT|BOSS|5|alexscaves:forsaken|STALL_SKIPPED"]
schedule clear aot:run_alexscaves/b05_base
schedule clear aot:run_alexscaves/b05_mid
schedule clear aot:run_alexscaves/b05_post
schedule clear aot:run_alexscaves/b05_end
function aot:run_alexscaves/b05_next
