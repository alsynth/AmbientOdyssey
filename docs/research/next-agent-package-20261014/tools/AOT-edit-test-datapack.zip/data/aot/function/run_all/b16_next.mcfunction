kill @e[type=!minecraft:player]
schedule function aot:run_all/b16_wait 40t
