scoreboard players set #run aot_s 0
scoreboard players set #idx aot_s 6
kill @e[type=!minecraft:player]
tellraw @a ["AOT|BOSS|6|twilightforest:ur_ghast|START"]
schedule function aot:run_all/b06_base 20t
schedule function aot:run_all/b06_watch 1700t
data modify storage aot:cur id set value "twilightforest:ur_ghast"
data modify storage aot:cur init set value "aot:init_boss"
function aot:summon with storage aot:cur
