scoreboard players set #run aot_s 0
tellraw @a ["AOT|BOSS|4|twilightforest:hydra|STALL_SKIPPED"]
schedule clear aot:run_all/b04_base
schedule clear aot:run_all/b04_mid
schedule clear aot:run_all/b04_post
schedule clear aot:run_all/b04_end
function aot:run_all/b04_next
