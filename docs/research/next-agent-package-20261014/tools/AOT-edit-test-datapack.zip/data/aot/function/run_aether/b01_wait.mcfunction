function aot:run_aether/b02_start
