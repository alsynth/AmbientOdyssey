tellraw @a ["AOT|BOSS|2|twilightforest:lich|GONE_AFTER_A"]
schedule function aot:run_all/b02_next 20t
