tellraw @a ["AOT|BOSS|18|graveyard:lich|GONE_AFTER_A"]
schedule function aot:run_all/b18_next 20t
