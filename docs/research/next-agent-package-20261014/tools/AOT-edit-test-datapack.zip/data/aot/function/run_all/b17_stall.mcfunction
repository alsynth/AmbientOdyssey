scoreboard players set #run aot_s 0
tellraw @a ["AOT|BOSS|17|aquamirae:captain_cornelia|STALL_SKIPPED"]
schedule clear aot:run_all/b17_base
schedule clear aot:run_all/b17_mid
schedule clear aot:run_all/b17_post
schedule clear aot:run_all/b17_end
function aot:run_all/b17_next
