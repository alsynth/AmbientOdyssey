tellraw @a ["AOT|BOSS|11|undergarden:forgotten_guardian|NO_ENTITY"]
schedule function aot:run_all/b11_next 20t
