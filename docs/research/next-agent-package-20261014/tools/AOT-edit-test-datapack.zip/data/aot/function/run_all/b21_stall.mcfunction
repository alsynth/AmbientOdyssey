scoreboard players set #run aot_s 0
tellraw @a ["AOT|BOSS|21|netherman:azazel|STALL_SKIPPED"]
schedule clear aot:run_all/b21_base
schedule clear aot:run_all/b21_mid
schedule clear aot:run_all/b21_post
schedule clear aot:run_all/b21_end
function aot:run_all/b21_next
