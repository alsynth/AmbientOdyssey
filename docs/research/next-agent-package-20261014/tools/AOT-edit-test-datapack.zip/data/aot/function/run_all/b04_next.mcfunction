kill @e[type=!minecraft:player]
schedule function aot:run_all/b04_wait 40t
