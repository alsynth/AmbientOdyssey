kill @e[type=!minecraft:player]
schedule function aot:run_alexscaves/b01_wait 40t
