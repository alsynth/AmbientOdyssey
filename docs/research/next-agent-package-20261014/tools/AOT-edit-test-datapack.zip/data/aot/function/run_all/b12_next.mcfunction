kill @e[type=!minecraft:player]
schedule function aot:run_all/b12_wait 40t
