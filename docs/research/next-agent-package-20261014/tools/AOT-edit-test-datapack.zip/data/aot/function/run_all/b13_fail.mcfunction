tellraw @a ["AOT|BOSS|13|alexscaves:tremorzilla|NO_ENTITY"]
schedule function aot:run_all/b13_next 20t
