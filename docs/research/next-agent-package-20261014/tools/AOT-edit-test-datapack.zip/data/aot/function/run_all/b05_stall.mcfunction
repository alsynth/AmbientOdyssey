scoreboard players set #run aot_s 0
tellraw @a ["AOT|BOSS|5|twilightforest:knight_phantom|STALL_SKIPPED"]
schedule clear aot:run_all/b05_base
schedule clear aot:run_all/b05_mid
schedule clear aot:run_all/b05_post
schedule clear aot:run_all/b05_end
function aot:run_all/b05_next
