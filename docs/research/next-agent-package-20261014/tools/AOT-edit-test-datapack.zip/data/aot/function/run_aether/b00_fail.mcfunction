tellraw @a ["AOT|BOSS|0|minecraft:husk|NO_ENTITY"]
schedule function aot:run_aether/b00_next 20t
