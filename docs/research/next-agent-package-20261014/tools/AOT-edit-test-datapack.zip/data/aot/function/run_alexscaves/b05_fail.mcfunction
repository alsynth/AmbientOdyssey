tellraw @a ["AOT|BOSS|5|alexscaves:forsaken|NO_ENTITY"]
schedule function aot:run_alexscaves/b05_next 20t
