execute if score #st_ok aot_s matches 1 run tellraw @a "AOT|CHAIN|azazel|phase_ticks=600"
execute if score #st_ok aot_s matches 1 run function aot:run_azazel/b00_start
execute unless score #st_ok aot_s matches 1 run function aot:selftest_fail
