function aot:run_all/b16_start
