scoreboard players set #run aot_s 0
tellraw @a ["AOT|BOSS|3|alexscaves:atlatitan|STALL_SKIPPED"]
schedule clear aot:run_alexscaves/b03_base
schedule clear aot:run_alexscaves/b03_mid
schedule clear aot:run_alexscaves/b03_post
schedule clear aot:run_alexscaves/b03_end
function aot:run_alexscaves/b03_next
