function aot:run_all/b15_start
