tellraw @a ["AOT|BOSS|3|alexscaves:atlatitan|NO_ENTITY"]
schedule function aot:run_alexscaves/b03_next 20t
