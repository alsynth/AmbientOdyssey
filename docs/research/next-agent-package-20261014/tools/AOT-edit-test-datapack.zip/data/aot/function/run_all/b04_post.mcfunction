execute store result score #hp aot_s run data get entity @e[tag=aot_boss,limit=1,sort=nearest] Health 100
execute store success score #hasmax aot_s store result score #max aot_s run attribute @e[tag=aot_boss,limit=1,sort=nearest] minecraft:generic.max_health get 100
execute store success score #hasatk aot_s store result score #atk aot_s run attribute @e[tag=aot_boss,limit=1,sort=nearest] minecraft:generic.attack_damage get 100
tellraw @a ["AOT|MOD|",{"score":{"name":"#idx","objective":"aot_s"}},"|twilightforest:hydra|max100=",{"score":{"name":"#max","objective":"aot_s"}},"|atk100=",{"score":{"name":"#atk","objective":"aot_s"}},"|hp100=",{"score":{"name":"#hp","objective":"aot_s"}},"|hasmax=",{"score":{"name":"#hasmax","objective":"aot_s"}},"|hasatk=",{"score":{"name":"#hasatk","objective":"aot_s"}}]
scoreboard players set #cnt aot_s 0
scoreboard players set #sum aot_s 0
scoreboard players set #phase aot_s 2
scoreboard players operation #last aot_s = @p aot_dt
scoreboard players set #run aot_s 1
schedule function aot:run_all/b04_end 600t
