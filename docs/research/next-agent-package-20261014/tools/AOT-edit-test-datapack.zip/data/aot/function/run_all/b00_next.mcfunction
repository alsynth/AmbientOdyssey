kill @e[type=!minecraft:player]
schedule function aot:run_all/b00_wait 40t
