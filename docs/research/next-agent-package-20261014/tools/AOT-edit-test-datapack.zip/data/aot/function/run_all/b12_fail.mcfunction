tellraw @a ["AOT|BOSS|12|alexscaves:luxtructosaurus|NO_ENTITY"]
schedule function aot:run_all/b12_next 20t
