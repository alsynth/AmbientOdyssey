tellraw @a ["AOT|BOSS|1|twilightforest:naga|NO_ENTITY"]
schedule function aot:run_all/b01_next 20t
