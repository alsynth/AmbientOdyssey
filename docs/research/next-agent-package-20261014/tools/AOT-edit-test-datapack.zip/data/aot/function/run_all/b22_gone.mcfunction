tellraw @a ["AOT|BOSS|22|cataclysm:ignis|GONE_AFTER_A"]
schedule function aot:run_all/b22_next 20t
