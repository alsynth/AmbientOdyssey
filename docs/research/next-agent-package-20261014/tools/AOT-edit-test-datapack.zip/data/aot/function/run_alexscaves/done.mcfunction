scoreboard players set #run aot_s 0
scoreboard players set #active aot_s 0
kill @e[type=!minecraft:player]
tellraw @a ["AOT|ALL_DONE|alexscaves"]
tellraw @a {"text":"AOT test finished. Send logs/latest.log to Claude.","color":"green"}
