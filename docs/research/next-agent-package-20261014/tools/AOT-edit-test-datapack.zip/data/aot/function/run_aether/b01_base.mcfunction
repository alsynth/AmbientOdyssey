execute unless entity @e[tag=aot_boss] run function aot:run_aether/b01_fail
execute if entity @e[tag=aot_boss] run function aot:run_aether/b01_base2
