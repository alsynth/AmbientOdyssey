execute unless entity @e[tag=aot_boss] run function aot:run_alexscaves/b02_fail
execute if entity @e[tag=aot_boss] run function aot:run_alexscaves/b02_base2
