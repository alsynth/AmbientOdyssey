function aot:run_all/b08_start
