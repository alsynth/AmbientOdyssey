tellraw @a ["AOT|BOSS|4|twilightforest:hydra|NO_ENTITY"]
schedule function aot:run_all/b04_next 20t
