tellraw @a ["AOT|BOSS|1|aether:slider|NO_ENTITY"]
schedule function aot:run_aether/b01_next 20t
