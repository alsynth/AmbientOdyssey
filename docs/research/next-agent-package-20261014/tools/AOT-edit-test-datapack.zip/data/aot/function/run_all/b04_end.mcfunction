scoreboard players set #run aot_s 0
tellraw @a ["AOT|END|",{"score":{"name":"#idx","objective":"aot_s"}},"|B|cnt=",{"score":{"name":"#cnt","objective":"aot_s"}},"|sum10=",{"score":{"name":"#sum","objective":"aot_s"}}]
tellraw @a ["AOT|BOSS|4|twilightforest:hydra|DONE"]
schedule function aot:run_all/b04_next 20t
