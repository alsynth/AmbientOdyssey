execute unless entity @e[tag=aot_boss] run function aot:run_all/b09_fail
execute if entity @e[tag=aot_boss] run function aot:run_all/b09_base2
