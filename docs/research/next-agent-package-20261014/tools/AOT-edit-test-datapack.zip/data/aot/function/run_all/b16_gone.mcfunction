tellraw @a ["AOT|BOSS|16|alexscaves:forsaken|GONE_AFTER_A"]
schedule function aot:run_all/b16_next 20t
