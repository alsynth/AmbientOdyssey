scoreboard players set #run aot_s 0
tellraw @a ["AOT|BOSS|14|alexscaves:atlatitan|STALL_SKIPPED"]
schedule clear aot:run_all/b14_base
schedule clear aot:run_all/b14_mid
schedule clear aot:run_all/b14_post
schedule clear aot:run_all/b14_end
function aot:run_all/b14_next
