kill @e[type=!minecraft:player]
schedule function aot:run_all/b01_wait 40t
