tellraw @a ["AOT|BOSS|16|alexscaves:forsaken|NO_ENTITY"]
schedule function aot:run_all/b16_next 20t
