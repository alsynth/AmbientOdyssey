function aot:run_all/b02_start
