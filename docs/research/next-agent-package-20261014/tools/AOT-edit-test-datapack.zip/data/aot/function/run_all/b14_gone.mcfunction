tellraw @a ["AOT|BOSS|14|alexscaves:atlatitan|GONE_AFTER_A"]
schedule function aot:run_all/b14_next 20t
