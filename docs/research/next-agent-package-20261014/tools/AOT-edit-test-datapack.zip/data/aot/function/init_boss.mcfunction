tag @s add aot_boss
data modify entity @s PersistenceRequired set value 1b
