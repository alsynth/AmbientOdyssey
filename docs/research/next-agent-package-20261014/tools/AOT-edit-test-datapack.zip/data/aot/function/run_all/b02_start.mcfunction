scoreboard players set #run aot_s 0
scoreboard players set #idx aot_s 2
kill @e[type=!minecraft:player]
tellraw @a ["AOT|BOSS|2|twilightforest:lich|START"]
schedule function aot:run_all/b02_base 20t
schedule function aot:run_all/b02_watch 1700t
data modify storage aot:cur id set value "twilightforest:lich"
data modify storage aot:cur init set value "aot:init_boss"
function aot:summon with storage aot:cur
