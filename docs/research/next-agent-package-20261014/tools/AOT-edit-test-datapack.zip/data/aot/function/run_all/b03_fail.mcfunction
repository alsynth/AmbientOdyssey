tellraw @a ["AOT|BOSS|3|twilightforest:minoshroom|NO_ENTITY"]
schedule function aot:run_all/b03_next 20t
