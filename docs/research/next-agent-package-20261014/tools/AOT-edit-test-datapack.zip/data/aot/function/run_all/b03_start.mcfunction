scoreboard players set #run aot_s 0
scoreboard players set #idx aot_s 3
kill @e[type=!minecraft:player]
tellraw @a ["AOT|BOSS|3|twilightforest:minoshroom|START"]
schedule function aot:run_all/b03_base 20t
schedule function aot:run_all/b03_watch 1700t
data modify storage aot:cur id set value "twilightforest:minoshroom"
data modify storage aot:cur init set value "aot:init_boss"
function aot:summon with storage aot:cur
