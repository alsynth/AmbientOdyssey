tellraw @a ["AOT|BOSS|2|alexscaves:tremorzilla|NO_ENTITY"]
schedule function aot:run_alexscaves/b02_next 20t
