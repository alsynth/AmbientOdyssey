function aot:run_alexscaves/b02_start
