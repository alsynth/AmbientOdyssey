execute unless entity @e[tag=aot_boss] run function aot:run_alexscaves/b01_fail
execute if entity @e[tag=aot_boss] run function aot:run_alexscaves/b01_base2
