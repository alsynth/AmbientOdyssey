scoreboard players set #run aot_s 0
tellraw @a ["AOT|BOSS|7|twilightforest:snow_queen|STALL_SKIPPED"]
schedule clear aot:run_all/b07_base
schedule clear aot:run_all/b07_mid
schedule clear aot:run_all/b07_post
schedule clear aot:run_all/b07_end
function aot:run_all/b07_next
