tellraw @a ["AOT|BOSS|15|alexscaves:hullbreaker|GONE_AFTER_A"]
schedule function aot:run_all/b15_next 20t
