scoreboard players set #run aot_s 0
scoreboard players set #idx aot_s 21
kill @e[type=!minecraft:player]
tellraw @a ["AOT|BOSS|21|netherman:azazel|START"]
schedule function aot:run_all/b21_base 20t
schedule function aot:run_all/b21_watch 1700t
data modify storage aot:cur id set value "netherman:azazel"
data modify storage aot:cur init set value "aot:init_boss"
function aot:summon with storage aot:cur
