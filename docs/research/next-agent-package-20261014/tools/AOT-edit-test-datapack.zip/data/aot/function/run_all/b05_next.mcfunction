kill @e[type=!minecraft:player]
schedule function aot:run_all/b05_wait 40t
