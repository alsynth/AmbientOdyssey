scoreboard players set #run aot_s 0
tellraw @a ["AOT|BOSS|1|aether:slider|STALL_SKIPPED"]
schedule clear aot:run_aether/b01_base
schedule clear aot:run_aether/b01_mid
schedule clear aot:run_aether/b01_post
schedule clear aot:run_aether/b01_end
function aot:run_aether/b01_next
