effect give @e[tag=aot_boss,limit=1,sort=nearest] minecraft:fire_resistance 1000000 0 true
execute store result score #hp aot_s run data get entity @e[tag=aot_boss,limit=1,sort=nearest] Health 100
execute store success score #hasmax aot_s store result score #max aot_s run attribute @e[tag=aot_boss,limit=1,sort=nearest] minecraft:generic.max_health get 100
execute store success score #hasatk aot_s store result score #atk aot_s run attribute @e[tag=aot_boss,limit=1,sort=nearest] minecraft:generic.attack_damage get 100
tellraw @a ["AOT|BASE|",{"score":{"name":"#idx","objective":"aot_s"}},"|alexscaves:luxtructosaurus|max100=",{"score":{"name":"#max","objective":"aot_s"}},"|atk100=",{"score":{"name":"#atk","objective":"aot_s"}},"|hp100=",{"score":{"name":"#hp","objective":"aot_s"}},"|hasmax=",{"score":{"name":"#hasmax","objective":"aot_s"}},"|hasatk=",{"score":{"name":"#hasatk","objective":"aot_s"}}]
damage @e[tag=aot_boss,limit=1,sort=nearest] 1 minecraft:player_attack by @p
scoreboard players set #cnt aot_s 0
scoreboard players set #sum aot_s 0
scoreboard players set #phase aot_s 1
scoreboard players operation #last aot_s = @p aot_dt
scoreboard players set #run aot_s 1
schedule function aot:run_all/b12_mid 600t
