function aot:run_all/b01_start
