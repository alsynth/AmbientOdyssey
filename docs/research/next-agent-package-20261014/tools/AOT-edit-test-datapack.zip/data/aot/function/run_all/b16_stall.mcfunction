scoreboard players set #run aot_s 0
tellraw @a ["AOT|BOSS|16|alexscaves:forsaken|STALL_SKIPPED"]
schedule clear aot:run_all/b16_base
schedule clear aot:run_all/b16_mid
schedule clear aot:run_all/b16_post
schedule clear aot:run_all/b16_end
function aot:run_all/b16_next
