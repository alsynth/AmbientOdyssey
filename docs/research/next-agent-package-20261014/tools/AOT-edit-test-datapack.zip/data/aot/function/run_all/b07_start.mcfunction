scoreboard players set #run aot_s 0
scoreboard players set #idx aot_s 7
kill @e[type=!minecraft:player]
tellraw @a ["AOT|BOSS|7|twilightforest:snow_queen|START"]
schedule function aot:run_all/b07_base 20t
schedule function aot:run_all/b07_watch 1700t
data modify storage aot:cur id set value "twilightforest:snow_queen"
data modify storage aot:cur init set value "aot:init_boss"
function aot:summon with storage aot:cur
