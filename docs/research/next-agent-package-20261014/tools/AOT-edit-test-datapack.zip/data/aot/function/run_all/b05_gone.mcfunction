tellraw @a ["AOT|BOSS|5|twilightforest:knight_phantom|GONE_AFTER_A"]
schedule function aot:run_all/b05_next 20t
