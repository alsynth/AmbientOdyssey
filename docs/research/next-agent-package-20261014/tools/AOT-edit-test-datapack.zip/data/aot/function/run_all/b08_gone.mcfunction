tellraw @a ["AOT|BOSS|8|twilightforest:alpha_yeti|GONE_AFTER_A"]
schedule function aot:run_all/b08_next 20t
