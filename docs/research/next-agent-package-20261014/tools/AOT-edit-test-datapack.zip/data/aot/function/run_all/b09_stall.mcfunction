scoreboard players set #run aot_s 0
tellraw @a ["AOT|BOSS|9|aether:slider|STALL_SKIPPED"]
schedule clear aot:run_all/b09_base
schedule clear aot:run_all/b09_mid
schedule clear aot:run_all/b09_post
schedule clear aot:run_all/b09_end
function aot:run_all/b09_next
