function aot:run_all/b05_start
