function aot:run_all/b20_start
