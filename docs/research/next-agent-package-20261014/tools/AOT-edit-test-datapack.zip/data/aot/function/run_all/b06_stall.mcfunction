scoreboard players set #run aot_s 0
tellraw @a ["AOT|BOSS|6|twilightforest:ur_ghast|STALL_SKIPPED"]
schedule clear aot:run_all/b06_base
schedule clear aot:run_all/b06_mid
schedule clear aot:run_all/b06_post
schedule clear aot:run_all/b06_end
function aot:run_all/b06_next
