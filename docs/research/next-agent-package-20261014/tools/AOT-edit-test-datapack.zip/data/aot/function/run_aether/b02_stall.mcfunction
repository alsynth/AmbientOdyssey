scoreboard players set #run aot_s 0
tellraw @a ["AOT|BOSS|2|deep_aether:eots_controller|STALL_SKIPPED"]
schedule clear aot:run_aether/b02_base
schedule clear aot:run_aether/b02_mid
schedule clear aot:run_aether/b02_post
schedule clear aot:run_aether/b02_end
function aot:run_aether/b02_next
