tellraw @a ["AOT|BOSS|21|netherman:azazel|GONE_AFTER_A"]
schedule function aot:run_all/b21_next 20t
