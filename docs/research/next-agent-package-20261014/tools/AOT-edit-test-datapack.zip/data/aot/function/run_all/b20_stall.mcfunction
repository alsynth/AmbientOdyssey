scoreboard players set #run aot_s 0
tellraw @a ["AOT|BOSS|20|ars_nouveau:wilden_boss|STALL_SKIPPED"]
schedule clear aot:run_all/b20_base
schedule clear aot:run_all/b20_mid
schedule clear aot:run_all/b20_post
schedule clear aot:run_all/b20_end
function aot:run_all/b20_next
