scoreboard players set #run aot_s 0
scoreboard players set #idx aot_s 1
kill @e[type=!minecraft:player]
tellraw @a ["AOT|BOSS|1|alexscaves:luxtructosaurus|START"]
schedule function aot:run_alexscaves/b01_base 20t
schedule function aot:run_alexscaves/b01_watch 1700t
data modify storage aot:cur id set value "alexscaves:luxtructosaurus"
data modify storage aot:cur init set value "aot:init_boss"
function aot:summon with storage aot:cur
