function aot:run_all/b07_start
