scoreboard players set #run aot_s 0
scoreboard players set #idx aot_s 11
kill @e[type=!minecraft:player]
tellraw @a ["AOT|BOSS|11|undergarden:forgotten_guardian|START"]
schedule function aot:run_all/b11_base 20t
schedule function aot:run_all/b11_watch 1700t
data modify storage aot:cur id set value "undergarden:forgotten_guardian"
data modify storage aot:cur init set value "aot:init_boss"
function aot:summon with storage aot:cur
