function aot:run_all/b19_start
