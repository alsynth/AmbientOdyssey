tellraw @a ["AOT|BOSS|4|twilightforest:hydra|GONE_AFTER_A"]
schedule function aot:run_all/b04_next 20t
