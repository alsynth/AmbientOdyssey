execute unless entity @e[tag=aot_boss] run function aot:run_alexscaves/b00_fail
execute if entity @e[tag=aot_boss] run function aot:run_alexscaves/b00_base2
