kill @e[type=!minecraft:player]
schedule function aot:run_all/b11_wait 40t
