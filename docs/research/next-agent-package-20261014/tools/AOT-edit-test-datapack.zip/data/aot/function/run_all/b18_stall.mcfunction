scoreboard players set #run aot_s 0
tellraw @a ["AOT|BOSS|18|graveyard:lich|STALL_SKIPPED"]
schedule clear aot:run_all/b18_base
schedule clear aot:run_all/b18_mid
schedule clear aot:run_all/b18_post
schedule clear aot:run_all/b18_end
function aot:run_all/b18_next
