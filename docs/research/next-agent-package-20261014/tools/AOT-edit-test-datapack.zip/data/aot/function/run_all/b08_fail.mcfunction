tellraw @a ["AOT|BOSS|8|twilightforest:alpha_yeti|NO_ENTITY"]
schedule function aot:run_all/b08_next 20t
