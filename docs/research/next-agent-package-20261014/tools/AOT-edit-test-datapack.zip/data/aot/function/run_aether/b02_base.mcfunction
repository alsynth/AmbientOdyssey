execute unless entity @e[tag=aot_boss] run function aot:run_aether/b02_fail
execute if entity @e[tag=aot_boss] run function aot:run_aether/b02_base2
