tellraw @a ["AOT|BOSS|3|alexscaves:atlatitan|GONE_AFTER_A"]
schedule function aot:run_alexscaves/b03_next 20t
