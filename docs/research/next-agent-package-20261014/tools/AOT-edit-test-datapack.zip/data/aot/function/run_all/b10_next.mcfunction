kill @e[type=!minecraft:player]
schedule function aot:run_all/b10_wait 40t
