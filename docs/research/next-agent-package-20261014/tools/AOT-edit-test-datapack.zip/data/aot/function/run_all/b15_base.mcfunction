execute unless entity @e[tag=aot_boss] run function aot:run_all/b15_fail
execute if entity @e[tag=aot_boss] run function aot:run_all/b15_base2
