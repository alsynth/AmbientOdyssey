function aot:run_all/b09_start
