function aot:run_all/b03_start
