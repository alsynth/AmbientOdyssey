scoreboard players operation #now aot_s = @p aot_dt
scoreboard players operation #delta aot_s = #now aot_s
scoreboard players operation #delta aot_s -= #last aot_s
execute if score #delta aot_s matches 1.. run function aot:log_hit
scoreboard players operation #last aot_s = #now aot_s
