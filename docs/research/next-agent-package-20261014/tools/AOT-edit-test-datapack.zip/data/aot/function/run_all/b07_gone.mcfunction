tellraw @a ["AOT|BOSS|7|twilightforest:snow_queen|GONE_AFTER_A"]
schedule function aot:run_all/b07_next 20t
