tellraw @a ["AOT|BOSS|6|twilightforest:ur_ghast|GONE_AFTER_A"]
schedule function aot:run_all/b06_next 20t
