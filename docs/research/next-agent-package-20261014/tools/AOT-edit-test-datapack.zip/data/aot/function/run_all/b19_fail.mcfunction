tellraw @a ["AOT|BOSS|19|graveyard:nightmare|NO_ENTITY"]
schedule function aot:run_all/b19_next 20t
