kill @e[type=!minecraft:player]
schedule function aot:run_all/b21_wait 40t
