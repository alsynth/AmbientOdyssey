kill @e[type=!minecraft:player]
schedule function aot:run_all/b02_wait 40t
