execute if score #st_ok aot_s matches 1 run function aot:run_all/b37_start
execute unless score #st_ok aot_s matches 1 run function aot:selftest_fail
