scoreboard players set #run aot_s 0
scoreboard players set #idx aot_s 8
kill @e[type=!minecraft:player]
tellraw @a ["AOT|BOSS|8|twilightforest:alpha_yeti|START"]
schedule function aot:run_all/b08_base 20t
schedule function aot:run_all/b08_watch 1700t
data modify storage aot:cur id set value "twilightforest:alpha_yeti"
data modify storage aot:cur init set value "aot:init_boss"
function aot:summon with storage aot:cur
