execute unless entity @e[tag=aot_boss] run function aot:run_alexscaves/b04_fail
execute if entity @e[tag=aot_boss] run function aot:run_alexscaves/b04_base2
