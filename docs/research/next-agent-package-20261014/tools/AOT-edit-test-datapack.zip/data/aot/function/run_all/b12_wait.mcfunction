function aot:run_all/b13_start
