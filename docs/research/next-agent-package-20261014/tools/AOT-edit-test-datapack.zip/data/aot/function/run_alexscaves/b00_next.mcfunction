kill @e[type=!minecraft:player]
schedule function aot:run_alexscaves/b00_wait 40t
