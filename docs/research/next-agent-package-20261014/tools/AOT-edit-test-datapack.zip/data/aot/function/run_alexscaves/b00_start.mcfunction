scoreboard players set #run aot_s 0
scoreboard players set #idx aot_s 0
kill @e[type=!minecraft:player]
tellraw @a ["AOT|BOSS|0|minecraft:husk|START"]
schedule function aot:run_alexscaves/b00_base 20t
schedule function aot:run_alexscaves/b00_watch 1700t
data modify storage aot:cur id set value "minecraft:husk"
data modify storage aot:cur init set value "aot:init_boss"
function aot:summon with storage aot:cur
