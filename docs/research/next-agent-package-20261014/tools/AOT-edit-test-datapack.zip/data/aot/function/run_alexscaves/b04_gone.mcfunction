tellraw @a ["AOT|BOSS|4|alexscaves:hullbreaker|GONE_AFTER_A"]
schedule function aot:run_alexscaves/b04_next 20t
