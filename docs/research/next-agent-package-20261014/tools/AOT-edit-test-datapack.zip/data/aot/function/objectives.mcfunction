scoreboard objectives add aot_s dummy
scoreboard objectives add aot_dt minecraft.custom:minecraft.damage_taken
