scoreboard players set #run aot_s 0
scoreboard players set #idx aot_s 13
kill @e[type=!minecraft:player]
tellraw @a ["AOT|BOSS|13|alexscaves:tremorzilla|START"]
schedule function aot:run_all/b13_base 20t
schedule function aot:run_all/b13_watch 1700t
data modify storage aot:cur id set value "alexscaves:tremorzilla"
data modify storage aot:cur init set value "aot:init_boss"
function aot:summon with storage aot:cur
