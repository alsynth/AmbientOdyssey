kill @e[type=!minecraft:player]
schedule function aot:run_aether/b02_wait 40t
