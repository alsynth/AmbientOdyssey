kill @e[type=!minecraft:player]
schedule function aot:run_alexscaves/b02_wait 40t
