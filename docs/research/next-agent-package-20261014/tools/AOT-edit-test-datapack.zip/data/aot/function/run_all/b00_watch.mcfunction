execute if score #active aot_s matches 1 if score #idx aot_s matches 0 run function aot:run_all/b00_stall
