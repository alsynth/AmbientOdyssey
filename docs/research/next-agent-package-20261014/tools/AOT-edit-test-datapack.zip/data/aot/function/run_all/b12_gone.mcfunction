tellraw @a ["AOT|BOSS|12|alexscaves:luxtructosaurus|GONE_AFTER_A"]
schedule function aot:run_all/b12_next 20t
