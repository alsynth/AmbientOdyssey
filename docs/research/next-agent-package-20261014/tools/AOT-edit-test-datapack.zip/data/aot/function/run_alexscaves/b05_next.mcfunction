kill @e[type=!minecraft:player]
schedule function aot:run_alexscaves/b05_wait 40t
