function aot:objectives
function aot:setup_rules
function aot:setup_player
scoreboard players set #run aot_s 0
scoreboard players set #active aot_s 1
kill @e[type=!minecraft:player]
schedule function aot:player_check 20t
schedule function aot:selftest_a 30t
scoreboard players set #st_ok aot_s 0
tellraw @a {"text":"AOT edit test starting. Stand still, stay in survival, do not fight the boss.","color":"yellow"}
tellraw @a ["AOT|DIFFICULTY|normal|PHASE_TICKS=600"]
