function aot:run_all/b10_start
