function aot:run_alexscaves/b05_start
