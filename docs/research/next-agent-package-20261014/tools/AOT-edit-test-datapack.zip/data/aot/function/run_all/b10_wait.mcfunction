function aot:run_all/b11_start
