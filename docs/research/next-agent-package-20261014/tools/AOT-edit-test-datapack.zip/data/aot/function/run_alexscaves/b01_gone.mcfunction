tellraw @a ["AOT|BOSS|1|alexscaves:luxtructosaurus|GONE_AFTER_A"]
schedule function aot:run_alexscaves/b01_next 20t
