scoreboard players set #run aot_s 0
tellraw @a ["AOT|BOSS|19|graveyard:nightmare|STALL_SKIPPED"]
schedule clear aot:run_all/b19_base
schedule clear aot:run_all/b19_mid
schedule clear aot:run_all/b19_post
schedule clear aot:run_all/b19_end
function aot:run_all/b19_next
